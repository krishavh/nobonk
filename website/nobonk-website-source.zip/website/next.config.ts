import type { NextConfig } from 'next';
// Static hosting has no /_next/image service. Serve the checked-in assets directly.
const nextConfig: NextConfig = { output: 'export', images: { unoptimized: true } };
export default nextConfig;
