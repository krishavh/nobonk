"""NoBonk campaign artwork. Blender geometry; conceptual display, not app UI.
Run with Blender --background --python render_nobonk_expressive.py.
"""
import bpy, math, os
from mathutils import Vector
OUT = os.path.dirname(os.path.abspath(__file__))
# Reuse the original scene's modeling helpers and precision phone assembly.
helpers = open(os.path.join(OUT, 'render_nobonk.py')).read().split('# A compact city tile')[0]
exec(helpers.replace("OUT='/Users/haarithd/nobonk-art'", 'OUT=' + repr(OUT)))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'nobonk-phone.blend'))
OUT = os.path.dirname(os.path.abspath(__file__))
for o in list(bpy.data.objects):
    if o.type in {'LIGHT', 'CAMERA'} or o.name.startswith(('Warm studio', 'Sculptural signal', 'Signal particle')):
        bpy.data.objects.remove(o, do_unlink=True)
forest = mat('Deep forest stage', (.009, .028, .027), .18, .32)
chalk = mat('Warm ceramic', (.78, .84, .77), .1, .26)
signal = mat('Chartreuse illuminated ceramic', (.55, .9, .025), .2, .25)
p = signal.node_tree.nodes.get('Principled BSDF')
p.inputs['Emission Color'].default_value = (.33, .65, .014, 1)
p.inputs['Emission Strength'].default_value = .35
amber = mat('Amber alert detail', (1, .22, .035), .22, .28)
cube('Infinite forest backdrop', (0,0,-.48), (200,200,.2), forest, 0)
phone = bpy.data.objects['Floating phone assembly']
phone.location = (-.95,-.1,.72)
phone.rotation_euler = (math.radians(8), math.radians(-12), math.radians(-12))
# A raised path makes the relation between camera, person and signal tangible.
cube('Satin pedestrian path', (2.05,.62,-.06), (2.6,5.8,.3), forest, .22)
for y in [-1.65,-.85,-.05,.75,1.55,2.35]:
    cube('Path inlay', (2.05,y,.102), (.72,.13,.015), chalk, .025)
person('Aware pedestrian', 2.05,.2,.11, signal, -.3)
for r in [.7,1.03,1.38]:
    ring('Detection ripple', (2.05,.2,.14), r, signal, .023)
# Chamfered corner brackets float around the person, never a solid cage.
for x in [1.49,2.61]:
    for z in [.22,2.03]:
        sx = 1 if x < 2 else -1
        sz = 1 if z < 1 else -1
        rod('Target corner horizontal', (x,-.18,z), (x+sx*.23,-.18,z), .023, signal)
        rod('Target corner vertical', (x,-.18,z), (x,-.18,z+sz*.29), .023, signal)
# Physical warning totem, with restrained amber punctuation.
cube('Alert marker base',(3.06,1.48,.22),(.34,.34,.2),chalk,.07)
rod('Alert marker',(3.06,1.48,.25),(3.06,1.48,.92),.095,amber)
ring('Camera signal echo',(0,-2.8,-.02),.31,signal,.022)
for i in range(5):
    uv('Signal bead', (.55+i*.18,-1.08+i*.18,.34+i*.06),(.042,.042,.042),signal)
setup((9,-12,17),(.65,.15,.75),10.6,1600,1100)
s=bpy.context.scene
s.cycles.samples=64
s.view_settings.exposure=.2
s.world.color=(.08,.08,.08)
for o in bpy.data.objects:
    if o.type=='LIGHT':
        o.data.energy *= .65
light((3,5,8),1800,5)
save('nobonk-awareness-hero')
# Separate 1024x500 Google Play composition. Typography is Blender text geometry.
cam=s.camera
right=cam.rotation_euler.to_quaternion() @ Vector((1,0,0))
cam.location -= right*3.55
cam.data.ortho_scale=17.6
s.render.resolution_x=2048;s.render.resolution_y=1000
def ink(name,color):
    m=bpy.data.materials.new(name);m.use_nodes=True
    n=m.node_tree.nodes;n.clear();e=n.new('ShaderNodeEmission');e.inputs[0].default_value=(*color,1);e.inputs[1].default_value=1
    o=n.new('ShaderNodeOutputMaterial');m.node_tree.links.new(e.outputs[0],o.inputs[0]);return m
type_white=ink('Type ivory',(.87,.92,.85));type_lime=ink('Type lime',(.58,.9,.05));type_muted=ink('Type pale sage',(.47,.61,.56))
font=bpy.data.fonts.load('/System/Library/Fonts/Supplemental/Arial Bold.ttf')
regular=bpy.data.fonts.load('/System/Library/Fonts/Supplemental/Arial.ttf')
def text_obj(name,body,x,y,size,material,bold=True):
    curve=bpy.data.curves.new(name,'FONT');curve.body=body;curve.size=size;curve.font=font if bold else regular
    ob=bpy.data.objects.new(name,curve);s.collection.objects.link(ob);ob.parent=cam;ob.location=(x,y,-13);ob.data.materials.append(material)
text_obj('Brand','NoBonk',-7.45,2.22,.87,type_white)
text_obj('Hero line one','Look up.',-7.48,.35,1.38,type_lime)
text_obj('Hero line two','Meet the world.',-7.45,-.68,.68,type_white)
text_obj('Description','On-device obstacle detection',-7.43,-1.60,.29,type_muted,False)
text_obj('Creator credit','BY KRISHAV',-7.43,-2.66,.27,type_white)
s.render.filepath=os.path.join(OUT,'nobonk-play-feature-blender-2048.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'nobonk-play-feature-blender.blend'))
bpy.ops.render.render(write_still=True)
im=bpy.data.images.load(s.render.filepath);im.scale(1024,500);im.filepath_raw=os.path.join(OUT,'nobonk-play-feature-blender-1024x500.png');im.file_format='PNG';im.save()
