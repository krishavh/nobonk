"""NoBonk: crisp milled path, obstacle and awareness brackets. No organic tubes."""
import bpy, math, os
from mathutils import Vector
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'crisp-v2')
os.makedirs(OUT, exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
def mat(name,c,rough=.6,metal=.1):
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
lime=mat('Matte signal lime',(.53,.85,.06),.58)
white=mat('Pale ceramic',(.77,.87,.82),.65)
amber=mat('Amber obstacle',(.95,.36,.035),.58)
bg=mat('Graphite',(.008,.017,.02),.85,0)
def polygon(name,pts,z,depth,material,bevel=.025):
 n=len(pts);vs=[(x,y,z) for x,y in pts]+[(x,y,z+depth) for x,y in pts];faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(vs,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.data.materials.append(material)
 if bevel:mod=o.modifiers.new('Precision bevel','BEVEL');mod.width=bevel;mod.segments=3
 o.modifiers.new('Weighted face normals','WEIGHTED_NORMAL');return o
# Crisp navigation ribbon: broad enough to read at 48 px, turning clear of the block.
polygon('Path with directional arrow',[(-.68,-.91),(-.30,-.91),(-.30,-.44),(.46,.12),(.46,.48),(.73,.48),(.27,1.02),(-.19,.48),(.08,.48),(.08,.30),(-.68,-.26)],.04,.12,lime,.028)
polygon('Obstacle',[(-.74,.23),(-.28,.23),(-.28,.68),(-.74,.68)],.045,.18,amber,.035)
# Framing corners suggest the camera recognizing the scene; thin, flat and understated.
polygon('Lower right sensor bracket',[(1.01,-.73),(1.01,-.98),(.77,-.98),(.77,-.91),(.93,-.91),(.93,-.73)],.012,.035,white,.012)
polygon('Upper left sensor bracket',[(-1.01,.74),(-1.01,.99),(-.77,.99),(-.77,.92),(-.94,.92),(-.94,.74)],.012,.035,white,.012)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.025));ground=bpy.context.object;ground.data.materials.append(bg)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=96;s.cycles.use_denoising=True;s.render.resolution_x=1024;s.render.resolution_y=1024;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.world.color=(.08,.08,.08);s.view_settings.view_transform='AgX';s.view_settings.exposure=-.3
for loc,power,size in [((-3,5,8),650,6),((4,-3,6),150,5)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(0,-.9,16));cam=bpy.context.object;cam.rotation_euler=(Vector((0,0,.05))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=2.9;s.camera=cam
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/nobonk-crisp-icon.blend')
s.render.filepath=OUT+'/nobonk-crisp-icon-1024.png';bpy.ops.render.render(write_still=True)
im=bpy.data.images.load(s.render.filepath);im.scale(512,512);im.filepath_raw=OUT+'/nobonk-crisp-play-512.png';im.file_format='PNG';im.save()
ground.hide_render=True;s.render.film_transparent=True;s.render.image_settings.color_mode='RGBA';cam.data.ortho_scale=4.3;s.render.filepath=OUT+'/nobonk-crisp-adaptive-1024.png';bpy.ops.render.render(write_still=True)
