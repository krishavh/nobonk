"""NoBonk launcher: a path turning around an obstacle, with an awareness arc."""
import bpy, math, os
from mathutils import Vector
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def material(name,color,metal=0,rough=.3):
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
lime=material('Awareness chartreuse',(.55,.9,.035),.15,.25)
amber=material('Nearby obstacle amber',(1,.31,.035),.12,.25)
forest=material('Deep forest',(.012,.032,.027),.08,.4)
def stroke(name,points,r,mat):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=24;c.bevel_depth=r;c.bevel_resolution=6;c.use_fill_caps=True
 s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for b,pt in zip(s.bezier_points,points):b.co=pt;b.handle_left_type='AUTO';b.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(mat);return o
def ball(name,loc,r,mat):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=24,radius=r,location=loc);o=bpy.context.object;o.name=name;o.data.materials.append(mat);bpy.ops.object.shade_smooth();return o
stroke('Path around obstacle',[(-.48,-.95,.25),(-.48,-.49,.25),(-.08,-.1,.25),(.28,.22,.25),(.28,.66,.25)],.19,lime)
ball('Path start',(-.48,-.95,.25),.19,lime)
stroke('Forward direction',[(-.09,.39,.25),(.28,.78,.25),(.65,.39,.25)],.19,lime)
ball('Left arrow tip',(-.09,.39,.25),.19,lime);ball('Right arrow tip',(.65,.39,.25),.19,lime)
ball('Object to notice',(-.68,.46,.29),.27,amber)
pts=[(1.23*math.cos(math.radians(a)),1.23*math.sin(math.radians(a)),.17) for a in range(20,161,10)]
stroke('Awareness arc',pts,.075,lime)
for p in [pts[0],pts[-1]]:ball('Arc cap',p,.075,lime)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.1));ground=bpy.context.object;ground.name='Forest background';ground.data.materials.append(forest)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=96;s.cycles.use_denoising=True;s.render.resolution_x=1024;s.render.resolution_y=1024;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.world.color=(.13,.13,.13);s.view_settings.view_transform='AgX';s.view_settings.exposure=.3
for loc,power,size in [((-3,-4,8),700,5),((3,4,6),1000,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(0,-3,15));cam=bpy.context.object;cam.rotation_euler=(Vector((0,.08,.1))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=3.1;s.camera=cam
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/nobonk-path-icon.blend')
s.render.image_settings.color_mode='RGB';s.render.filepath=OUT+'/nobonk-icon-master-1024.png';bpy.ops.render.render(write_still=True)
im=bpy.data.images.load(s.render.filepath);im.scale(512,512);im.filepath_raw=OUT+'/nobonk-play-icon-blender-512.png';im.file_format='PNG';im.save()
ground.hide_render=True;s.render.film_transparent=True;s.render.image_settings.color_mode='RGBA';cam.data.ortho_scale=4.6;s.render.filepath=OUT+'/nobonk-adaptive-foreground-1024.png';bpy.ops.render.render(write_still=True)
