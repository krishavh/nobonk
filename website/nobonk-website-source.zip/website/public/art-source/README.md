# NoBonk Blender campaign artwork

Concept illustrations, not app screenshots. Created with Blender 5.2.1.

- `nobonk-awareness-hero.blend`: website composition.
- `nobonk-play-feature-blender.blend`: 1024×500 Play composition, rendered at 2× resolution.
- `render_nobonk_expressive.py`: reproducible scene script. Keep `render_nobonk.py` and `nobonk-phone.blend` alongside it.
- The script uses Arial from the standard macOS Supplemental Fonts directory; adjust those two font paths on other operating systems.

Run `blender --background --python render_nobonk_expressive.py`. Output is written beside the script.

The conceptual phone display is illustrative. Use authentic device captures in Google Play screenshot slots.
