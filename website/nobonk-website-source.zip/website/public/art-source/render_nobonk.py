import bpy, math, os
from mathutils import Vector
OUT='/Users/haarithd/nobonk-art'
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
def mat(n,c,metal=0,rough=.45):
 m=bpy.data.materials.new(n); m.diffuse_color=(*c,1); m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
ivory=mat('Porcelain • warm ivory',(.79,.775,.71));lime=mat('Electric chartreuse',(.58,.88,.055),.1,.32);navy=mat('Midnight graphite',(.023,.042,.053),.2,.36);dark=mat('Black screen',(.006,.014,.015),.25,.22);road=mat('Warm stone asphalt',(.36,.385,.36));white=mat('Chalk',(.93,.94,.83));orange=mat('Safety vermilion',(.96,.22,.075));glass=mat('Desaturated glass',(.14,.215,.23),.45,.24)
def cube(n,loc,scale,ma,b=.05):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma)
 if b:mod=o.modifiers.new('Machined soft edges','BEVEL');mod.width=b;mod.segments=5;o.modifiers.new('Weighted studio normals','WEIGHTED_NORMAL')
 return o
def uv(n,loc,scale,ma):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(ma);bpy.ops.object.shade_smooth();return o
def rod(n,a,b,r,ma):
 d=Vector(b)-Vector(a);mid=(Vector(a)+Vector(b))/2;bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=r,depth=d.length,location=mid);o=bpy.context.object;o.name=n;o.rotation_euler=d.to_track_quat('Z','Y').to_euler();o.data.materials.append(ma);be=o.modifiers.new('Rounded ends','BEVEL');be.width=r*.85;be.segments=4;bpy.ops.object.shade_smooth();return o
def ring(n,center,r,ma,thick=.02):
 bpy.ops.mesh.primitive_torus_add(major_segments=128,minor_segments=12,location=center,major_radius=r,minor_radius=thick);o=bpy.context.object;o.name=n;o.data.materials.append(ma);bpy.ops.object.shade_smooth();return o
def person(n,x,y,z,ma,rot=0):
 def p(a,b,c):return (x+a*math.cos(rot)-b*math.sin(rot),y+a*math.sin(rot)+b*math.cos(rot),z+c)
 uv(n+' ceramic head',p(0,0,1.54),(.145,.14,.17),ma)
 uv(n+' body',p(0,0,1.06),(.2,.14,.34),ma)
 rod(n+' left leg',p(-.1,0,.88),p(-.12,-.21,.14),.085,ma);rod(n+' right leg',p(.1,0,.88),p(.12,.23,.14),.085,ma)
 uv(n+' shoe A',p(-.12,-.23,.09),(.1,.17,.08),ma);uv(n+' shoe B',p(.12,.21,.09),(.1,.17,.08),ma)
 rod(n+' left arm',p(-.17,0,1.26),p(-.29,.16,.84),.067,ma);rod(n+' right arm',p(.17,0,1.26),p(.3,-.2,.95),.067,ma)
def light(loc,power,size):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
def setup(camera,target,ortho,w,h):
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=32;s.cycles.use_denoising=True;s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100;s.world.color=(.24,.24,.24)
 s.view_settings.view_transform='AgX';s.view_settings.exposure=.55;s.render.image_settings.file_format='PNG';s.render.film_transparent=False
 bpy.ops.object.camera_add(location=camera);o=bpy.context.object;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();o.data.type='ORTHO';o.data.ortho_scale=ortho;s.camera=o
 light((-5,-6,11),1800,7);light((5,2,8),1200,6)
def save(name):
 bpy.ops.wm.save_as_mainfile(filepath=OUT+'/'+name+'.blend');bpy.context.scene.render.filepath=OUT+'/'+name+'.png';bpy.ops.render.render(write_still=True)
# A compact city tile with tactile architectural detailing and figurative walkers.
cube('Endless warm paper',(0,0,-.5),(200,200,.25),ivory,0)
cube('City model plinth',(0,0,-.15),(10,8,.5),ivory,.22)
cube('Pedestrian street',(0,-.6,.13),(10,3.65,.13),road,.04)
cube('Raised north sidewalk',(0,2.72,.23),(10,1.45,.32),ivory,.07)
cube('Raised south sidewalk',(0,-3.27,.23),(10,1.15,.32),ivory,.07)
for x in [-1.1,-.55,0,.55,1.1]:cube('Inlaid zebra crossing',(x,-.64,.208),(.33,3.4,.027),white,.016)
for x in [-4.4,-3.35,-2.3,2.3,3.35,4.4]:cube('Road center dash',(x,-.58,.21),(.57,.055,.025),white,.005)
# Back architectural massing with inset panels, setbacks and roof lip.
for x,y,w,d,h in [(-3.25,2.65,2.25,1.55,3.7),(-.55,3,1.7,1.1,2.45),(2.4,2.83,2.8,1.7,4.5)]:
 cube('Architectural monolith',(x,y,h/2+.4),(w,d,h),navy,.095)
 cube('Floating roof coping',(x,y,h+.44),(w+.1,d+.1,.12),navy,.035)
 for xx in range(int(w/.42)):
  for zz in range(int((h-.55)/.65)):
   cube('Recessed window',(x-w/2+.28+xx*.43,y-d/2-.013,.92+zz*.65),(.17,.028,.34),glass,.012)
 cube('Door portal',(x,y-d/2-.02,.88),(.48,.045,.93),dark,.025)
# Ceramic trees have multi lobed sculpted crowns.
for x,y in [(-4.3,-3.1),(3.8,-3.12),(.68,2.5)]:
 rod('Tree trunk',(x,y,.35),(x,y,1.63),.072,navy)
 for dx,dy,z,r in [(0,0,1.95,.43),(-.2,.07,1.7,.34),(.22,.02,1.77,.35)]:uv('Sculpted foliage',(x+dx,y+dy,z),(r,r*.8,r*1.12),lime)
person('Tracked pedestrian',.35,-.9,.25,lime,-.1)
person('Passing pedestrian',-2.7,-2.9,.4,navy,.4)
person('Distant pedestrian',1.4,1.35,.34,ivory,math.pi)
for r in [.66,.94,1.24]:ring('Proximity field',(.35,-.9,.24),r,lime,.016)
# Detection frame upright, slight edges and corner articulation.
for a,b in [((-.12,-1.05,.28),(-.12,-1.05,2.05)),((.8,-1.05,.28),(.8,-1.05,2.05)),((-.12,-1.05,2.05),(.8,-1.05,2.05))]:rod('Detection volume',a,b,.016,lime)
# Hazard furniture.
for x,y in [(2,-1.4),(2.65,-1.4)]:
 cube('Bollard foot',(x,y,.3),(.32,.32,.16),navy,.045);rod('Safety bollard',(x,y,.3),(x,y,.95),.084,orange);rod('Reflective band',(x,y,.72),(x,y,.83),.087,white)
cube('Street bench seat',(-2.8,1.36,.8),(1.3,.4,.12),navy,.045)
for x in [-3.25,-2.35]:cube('Bench support',(x,1.36,.57),(.09,.29,.4),navy,.02)
setup((11,-15,13),(0,0,1.4),16.4,1600,1100)
save('nobonk-city')
# Phone still life, screen uses actual layered geometry.
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
cube('Warm studio sweep',(0,0,-.44),(200,200,.2),ivory,0)
phone=[]
def pc(n,loc,dims,ma,bev):
 o=cube(n,loc,dims,ma,bev);phone.append(o);return o
pc('Graphite phone chassis',(0,0,0),(2.8,5.45,.27),navy,.25)
pc('Screen bezel',(0,0,.15),(2.67,5.29,.06),dark,.22)
pc('Detection display',(0,-.03,.185),(2.48,4.98,.025),glass,.17)
# Abstract scene on screen, architectural silhouettes and a hazard detection graphic.
pc('Screen roadway',(0,-.83,.208),(2.32,2.65,.018),road,.07)
for x,y,w,h in [(-.89,.5,.38,1.8),(-.4,.86,.4,1.08),(.68,.74,.79,1.31)]:pc('Screen urban silhouette',(x,y,.23),(w,h,.025),navy,.025)
for y in [-1.8,-1.4,-1,-.6]:pc('Screen walkway mark',(-.28,y,.239),(.73,.12,.016),ivory,.012)
# Target shape in screen plane and corner-only bounding box.
pc('Detected obstacle',( .5,-.7,.251),(.35,.78,.025),orange,.08)
for x in [.13,.88]:
 for y in [-1.28,-.1]:
  sx=1 if x<.5 else -1;sy=1 if y<-.5 else -1
  pc('Lime target corner',(x+sx*.11,y,.286),(.24,.045,.028),lime,.015)
  pc('Lime target corner',(x,y+sy*.13,.286),(.045,.28,.028),lime,.015)
pc('Earpiece',(0,2.42,.222),(.55,.04,.022),navy,.02)
pc('Gesture bar',(0,-2.39,.222),(.65,.045,.022),white,.02)
pc('Volume button',(-1.417,.98,.013),(.06,.8,.09),navy,.03)
pc('Power button',(1.417,.68,.013),(.06,.55,.09),navy,.03)
# Rotate the complete product as a single precision assembly.
bpy.ops.object.empty_add(location=(0,0,0));parent=bpy.context.object;parent.name='Floating phone assembly'
for o in phone:o.parent=parent
parent.rotation_euler=(math.radians(11),math.radians(-13),math.radians(-16));parent.location=(-.8,.1,.9)
for r in [1.32,1.76,2.2]:ring('Sculptural signal ring',(1.7,.55,.12),r,lime,.055)
# subtle levitating disks echo sensor returns.
for loc,r in [((2.96,-1.5,.36),.16),((3.65,.55,.65),.11),((2.4,2.1,.6),.22)]:uv('Signal particle',loc,(r,r,r),lime)
setup((7,-9,15),(0,0,.65),9,1200,1000)
save('nobonk-phone')
