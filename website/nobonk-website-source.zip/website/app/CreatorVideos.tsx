'use client';

import { useState } from 'react';
import Image from 'next/image';
import { ArrowUpRight, Play, X } from 'lucide-react';
import { BRAND_ICON } from './brand';

const stories = [
  { id: 'uj7l9rwRWSQ', label: 'THE APP, IN HIS OWN WORDS', title: 'Take a look with Krishav.', duration: '1:57', description: 'A hands-on Android walkthrough: settings, cues and a demonstration of alerts while another app is open.', note: 'Recorded September 2026. Background demonstration starts around 1:14. This recording shows a test build; controls can change.' },
  { id: 'MhQoMuKx1zM', label: 'FROM THE PROJECT ARCHIVE', title: 'Before the app, a question.', duration: '1:31', description: 'Krishav explains the school-hallway problem, the ideas he considered, and why he wanted the phone itself to help.', note: 'Original project presentation, February 2026. It describes early goals and stronger distance/collision claims, not verified guarantees for today’s app. Distance is approximate; alerts can miss hazards.' },
];

export default function CreatorVideos() {
  const [playing, setPlaying] = useState<{ id: string; start: number } | null>(null);
  return <section id="creator-videos" className="creator-videos wrap" aria-labelledby="creator-videos-title">
    <div className="creator-heading"><div><p className="eyebrow">THE PERSON BEHIND THE PROJECT</p><h2 id="creator-videos-title">A real question.<br/><span className="italic">His own voice.</span></h2></div><p>From an idea at school to an app on a phone. Hear Krishav explain why he started, then watch him try what he built.</p></div>
    <div className="creator-grid">{stories.map((story, index) => <article className="creator-card" key={story.id}>
      <div className="creator-player">
        {playing?.id === story.id ? <iframe key={`${story.id}-${playing.start}`} title={story.title}
          src={`https://www.youtube-nocookie.com/embed/${story.id}?autoplay=1&playsinline=1&rel=0&start=${playing.start}`}
          allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin" /> : <button className="creator-poster" onClick={() => setPlaying({ id: story.id, start: 0 })} aria-label={`Play ${story.title} on YouTube in this page`}>
          <span className="creator-poster-top"><Image src={BRAND_ICON} width="42" height="42" alt=""/><span>NOBONK / BY KRISHAV</span><small>{story.duration}</small></span>
          <span className="creator-poster-title">{index === 0 ? <>Let me<br/>show you.</> : <>What if<br/>your phone helped?</>}</span>
          <span className="creator-play"><Play size={21} fill="currentColor"/> Play video <ArrowUpRight size={18}/></span>
        </button>}
      </div>
      <div className="creator-card-copy"><p className="eyebrow">{story.label}</p><h3>{story.title}</h3><p>{story.description}</p><p className="creator-context">{story.note}</p>
        <div className="creator-links">{index === 0 && <button onClick={() => setPlaying({ id: story.id, start: 74 })}>Jump to background · 1:14</button>}<a href={`https://www.youtube.com/watch?v=${story.id}`} target="_blank" rel="noreferrer">Watch on YouTube <ArrowUpRight size={16}/></a>{playing?.id === story.id && <button onClick={() => setPlaying(null)}><X size={16}/> Close video</button>}</div>
      </div>
    </article>)}</div>
    <p className="creator-privacy">YouTube loads only after you choose to play. Its privacy policies then apply. Only one of these videos plays here at a time.</p>
  </section>;
}
