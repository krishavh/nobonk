import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'NoBonk · GenWhy',
  description: 'Explore NoBonk: on-device obstacle awareness, interactive alert logic, and honest prototype results. Coming soon on Google Play.',
  metadataBase: new URL('https://nobonk.genwhy.ai'),
  alternates: { canonical: '/' },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
