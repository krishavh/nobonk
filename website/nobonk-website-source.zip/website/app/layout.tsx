import type { Metadata } from 'next';
import './globals.css';
import { BRAND_ICON } from './brand';

export const metadata: Metadata = {
  title: 'NoBonk · GenWhy',
  description: 'NoBonk brings on-device obstacle alerts to Android while another app is open. Watch the real background demo and join the free Google Play closed test. Explore the iPhone Browse & scan development preview.',
  icons: { icon: BRAND_ICON, apple: BRAND_ICON },
  metadataBase: new URL('https://nobonk.genwhy.ai'),
  alternates: { canonical: '/' },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
