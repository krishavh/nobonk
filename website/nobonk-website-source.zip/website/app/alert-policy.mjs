// Educational port of NoBonk AlertPolicy.kt, person ladder, reference 2 m preset.
export function personAlert(fillPercent, approaching, imminent) {
  const fill = Math.max(0, Math.min(100, Number(fillPercent) || 0)) / 100;
  let level = fill >= .60 ? 3 : fill >= .42 ? 2 : fill >= .28 ? 1 : 0;
  if (approaching) level = Math.min(3, level + 1);
  if (imminent) level = 3;
  return { level, label: ['CLEAR', 'LOW', 'MEDIUM', 'HIGH'][level] };
}
