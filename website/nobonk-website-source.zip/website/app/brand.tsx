/** One approved icon for every NoBonk brand placement. */
export const BRAND_ICON = '/images/icon-v2/nobonk-crisp-play-512.png';

export function BrandLink() {
  return <a href="/" className="brand" aria-label="NoBonk home">
    <img className="brand-icon" src={BRAND_ICON} width="38" height="38" alt="" />
    <span>NoBonk<span className="brand-dot">.</span></span>
  </a>;
}
