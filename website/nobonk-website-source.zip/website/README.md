# NoBonk website

Public website for [nobonk.genwhy.ai](https://nobonk.genwhy.ai), an Android obstacle-awareness prototype by Krishav.

## Develop

Node 22.13+ is required. Run `npm ci`, `npm run dev`, and `npm run build`. Static output is `dist/client`.

The interactive educational demo ports the person alert ladder at the 2 m reference sensitivity from `krishavh/nobonk` commit `23a5452db093a8547e63ddd80adad8c0884debae`. It exposes frame height, approaching and imminent signals; the full Android pipeline applies additional filtering and timing. Reported performance and awards are attributed to the project README. No camera is accessed by this website.

## Original Blender artwork

`public/images/nobonk-city.webp` and `nobonk-phone.webp` are original Blender renders, illustrative rather than screenshots. `public/art-source/render_nobonk.py` recreates the scenes using Blender. Editable .blend files are included in the GitHub source bundle. No external stock imagery or remote fonts are used.

## Publication

Hosted publicly on Cloudflare infrastructure through Sites. Project metadata is in `.openai/hosting.json`. Source credentials, signing keys and passwords are never part of this project.
